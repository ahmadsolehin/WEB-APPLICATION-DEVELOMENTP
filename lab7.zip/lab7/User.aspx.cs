﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User : System.Web.UI.Page
{
    int pricePhp = 0;
    int priceHtml = 0;
    int priceCss = 0;
    double total;
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (CheckBox1.Checked == true )
        {
            pricePhp = 500;
            Session["php"] = CheckBox1.Text;
        }
        else {
            pricePhp = 0;
            Session["php"] = "";
        }

        if (CheckBox2.Checked == true)
        {
            priceHtml = 400;
            Session["html"] = CheckBox2.Text;
        }
        else {
            priceHtml = 0;
            Session["html"] = "";
        }

        if (CheckBox3.Checked == true)
        {
            priceCss = 300;
            Session["css"] = CheckBox3.Text;
        }
        else {
            priceCss = 0;
            Session["css"] = "";
        }

        total = priceCss + priceHtml + pricePhp;
        Session["total"] = total;
        Response.Redirect("Fee.aspx");
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = "Hi, " + Session["username"].ToString();
    }
}