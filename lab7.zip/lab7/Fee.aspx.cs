﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Fee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = "You selected course(s) : ";
        Label2.Text = Session["php"].ToString();
        Label3.Text = Session["html"].ToString();
        Label4.Text = Session["css"].ToString();
        Label5.Text = "Fee : RM" + Session["total"].ToString();
    }
}